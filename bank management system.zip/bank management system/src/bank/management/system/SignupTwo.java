package bank.management.system;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;


public class SignupTwo extends JFrame implements ActionListener {
    //long random;
    JTextField pan, aadhar;
    JButton next;
    JRadioButton syes,sno,eyes,eno;
    //JDateChooser dateChooser;
    JComboBox religion,category,income,occupation,education;
    String formno;
    
    
    SignupTwo(String formno){
        this.formno = formno;
        setLayout(null);
        setTitle("New Account Application Form - Page 2");
        
        JLabel additionDetails = new JLabel("Page 2: Additional Details");
        additionDetails.setFont(new Font("Raleway",Font.BOLD,22));
        additionDetails.setBounds(290,80,300,30);
        add(additionDetails);
        
        JLabel rel = new JLabel("Religion: ");
        rel.setFont(new Font("Raleway",Font.BOLD,20));
        rel.setBounds(100,140,100,30);
        add(rel);
        
        String valReligion[] = {"Hindu","Muslim","Sikh","Christian","Others"};
        religion = new JComboBox(valReligion);
        religion.setBounds(300,140,400,30);
        religion.setBackground(Color.WHITE);
        add(religion);
                
        JLabel cat = new JLabel("Category: ");
        cat.setFont(new Font("Raleway",Font.BOLD,20));
        cat.setBounds(100,190,150,30);
        add(cat);
        
        String valcategory[] = {"General","OBC","SC","ST","Others"};
        category = new JComboBox(valcategory);
        category.setBounds(300,190,400,30);
        category.setBackground(Color.WHITE);
        add(category);
        
        JLabel inco = new JLabel("Income: ");
        inco.setFont(new Font("Raleway",Font.BOLD,20));
        inco.setBounds(100,240,150,30);
        add(inco);
        
        String incomecategory[] = {"Null","< 1,50,000","< 2,50,000","< 5,00,000","Upto 10,00,000"};
        income = new JComboBox(incomecategory);
        income.setBounds(300,240,400,30);
        income.setBackground(Color.WHITE);
        add(income);
        
        JLabel educat = new JLabel("Educational ");
        educat.setFont(new Font("Raleway",Font.BOLD,20));
        educat.setBounds(100,290,150,30);
        add(educat);
        
        JLabel qual = new JLabel("Qualifications: ");
        qual.setFont(new Font("Raleway",Font.BOLD,20));
        qual.setBounds(100,315,150,30);
        add(qual);
        
        String educationValues[] = {"Non-Graduate","Graduate","Post-Graduation","Doctrate","Others"};
        education = new JComboBox(educationValues);
        education.setBounds(300,315,400,30);
        education.setBackground(Color.WHITE);
        add(education);
        
        JLabel occup = new JLabel("Occupation: ");
        occup.setFont(new Font("Raleway",Font.BOLD,20));
        occup.setBounds(100,390,150,30);
        add(occup);
        
        String occupationValues[] = {"Salaried","Self-Employed","Business","Student","Retired","Agriculture","Others"};
        occupation = new JComboBox(occupationValues);
        occupation.setBounds(300,390,400,30);
        occupation.setBackground(Color.WHITE);
        add(occupation);
        
        JLabel panno = new JLabel("Pan Nnumber: ");
        panno.setFont(new Font("Raleway",Font.BOLD,20));
        panno.setBounds(100,440,150,30);
        add(panno);
        
        pan = new JTextField();
        pan.setFont(new Font("Raleway",Font.BOLD,14));
        pan.setBounds(300,440,400,30);
        add(pan);
        
        JLabel aadharno = new JLabel("Aadhar No: ");
        aadharno.setFont(new Font("Raleway",Font.BOLD,20));
        aadharno.setBounds(100,490,150,30);
        add(aadharno);
        
        aadhar = new JTextField();
        aadhar.setFont(new Font("Raleway",Font.BOLD,14));
        aadhar.setBounds(300,490,400,30);
        add(aadhar);
        
        JLabel seniorCitizen = new JLabel("Senior Citizen: ");
        seniorCitizen.setFont(new Font("Raleway",Font.BOLD,20));
        seniorCitizen.setBounds(100,540,150,30);
        add(seniorCitizen);
        
        syes = new JRadioButton("Yes");
        syes.setBounds(300,540,100,30);
        syes.setBackground(Color.WHITE);
        add(syes);
        
        sno = new JRadioButton("No");
        sno.setBounds(450,540,100,30);
        sno.setBackground(Color.WHITE);
        add(sno);
        
        ButtonGroup maritalgroup=new ButtonGroup();
        maritalgroup.add(syes);
        maritalgroup.add(sno);
        
        JLabel exAccount = new JLabel("Existing Account: ");
        exAccount.setFont(new Font("Raleway",Font.BOLD,20));
        exAccount.setBounds(100,590,180,30);
        add(exAccount);
        
        eyes = new JRadioButton("Yes");
        eyes.setBounds(300,590,100,30);
        eyes.setBackground(Color.WHITE);
        add(eyes);
        
        eno = new JRadioButton("No");
        eno.setBounds(450,590,100,30);
        eno.setBackground(Color.WHITE);
        add(eno);
        
        ButtonGroup emaritalgroup=new ButtonGroup();
        emaritalgroup.add(eyes);
        emaritalgroup.add(eno);
        
        next=new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway",Font.BOLD,14));
        next.setBounds(620,660,80,30);
        next.addActionListener(this);
        add(next);
        
        getContentPane().setBackground(Color.WHITE);
        
        /*setTitle("New Account Application Form - Page 1");*/
        setSize(850,800);
        setVisible(true);
        setLocation(350,10);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    @Override
    public void actionPerformed (ActionEvent ae){
        //String formno = "" + random;
        String sreligion = (String) religion.getSelectedItem();
        String scategory = (String) category.getSelectedItem();
        String sincome = (String) income.getSelectedItem();
        String seducation = (String) education.getSelectedItem();
        String soccupation = (String) occupation.getSelectedItem();
        
        String seniorcitizen = null;
        if (syes.isSelected()){
            seniorcitizen = "Yes";
        }else if(sno.isSelected()){
            seniorcitizen = "No";
        } 
        
        //String email = emailTextField.getText();
        String existingaccount = null;
        if (eyes.isSelected()){
            existingaccount = "Yes";
        }else if(eno.isSelected()){
            existingaccount = "No";
        }
        
        String span = pan.getText();
        String saadhar = aadhar.getText();
        
        // String state = stateTextField.getText();
       // String pin = pinTextField.getText();
        
        try{
            Conn c = new Conn();
            String query = "insert into signuptwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+seducation+"','"+soccupation+"','"+span+"','"+saadhar+"','"+seniorcitizen+"','"+existingaccount+"')";
            c.s.executeUpdate(query);
            
            //signup3 object
            setVisible(false);
            new SignupThree(formno).setVisible(true);
            }catch (Exception e){
            System.out.println(e);
        }
        
    }
    
    
    
    public static void main(String args[]){
        new SignupTwo("");
    }
    
}
